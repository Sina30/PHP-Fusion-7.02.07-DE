<?php
function checklinks_ext($url, &$name_info, &$url_info, &$status_info)
{
  global $userdata;

  if ($url === 0) return TRUE;
  if ($source = @file_get_contents($url))
  {
    $status = TRUE;
    
    $link = preg_match("/<a\s[^>]*href\s*=\s*([\"\']??)([^\" >]*?)(.*)php-fusion.co.uk(.*)[^>]*>(.*)(<img\s[^>]*src\s*=\s*([\"\']??)([^\" >]*?)*[^>]*>|php-fusion|phpfusion)(.*)<\/a>/siU", $source, $link);
    $license = preg_match("/<a\s[^>]*href\s*=\s*([\"\']??)([^\" >]*?)(.*)[^>]*>(.*)(affero|agpl)(.*)<\/a>/siU", $source, $license);
    getcontactinfo($url, $email, $ver);
    getuserfromemail($email, $user_id, $user);
    
    if ($email != '') $email = "<a href='mailto:".$email."'>".$email."</a>";
    if ($user != '') $user = "<a href='".BASEDIR."profile.php?lookup=".$user_id."'>".$user."</a>";

    $name_info = ($ver == '')? "[unknown]": "PHP-Fusion v".$ver;
    $url_info = (($user == '')? "[unknown]": $user)." at ".(($email == '')? "[unknown]": $email);
    $status_info = ($link == 0? "<div style='color:red'>": "<div style='color:green'>")."pf</div>".($license == 0? "<div style='color:red'>": "<div style='color:green'>")."agpl</div>";
  }
  else
  {
    $status = FALSE;
  }
  
  return $status;
}

function getcontactinfo($url, &$email, &$ver)
{
  $email = '';
  $ver = '';
  
  $url_array = parseurl($url);
  $url_contact = buildurl($url_array, 'contact.php');
  
  if ($source = @file_get_contents($url_contact))
  {
    if (preg_match("/script[\s]*type[\s]*=[\s]*\'text\/javascript\'[\s]*>[\s]*ML[\s]*\=[\s]*\"(.*)\"[\s]*;[\s]*MI[\s]*\=[\s]*\"(.*)\"[\s]*;[\s]*ML[\s]*\=[\s]*ML\.replace[\s]*\([\s]*\/(.*)\/g[\s]*,[\s]*\'<\'[\s]*\)[\s]*;[\s]*MI[\s]*\=[\s]*MI\.replace[\s]*\([\s]*\/(.*)\/g[\s]*,[\s]*\'<\'[\s]*\)[\s]*;[\s]*OT[\s]*\=[\s]*\"\"[\s]*;[\s]*for[\s]*\([\s]*j[\s]*\=[\s]*0[\s]*;[\s]*j[\s]*<[\s]*MI\.length[\s]*;[\s]*j\+\+[\s]*\)[\s]*{[\s]*OT[\s]*\+\=[\s]*ML\.charAt[\s]*\([\s]*MI\.charCodeAt[\s]*\([\s]*j[\s]*\)[\s]*\-[\s]*([0-9]+)[\s]*\)[\s]*;[\s]*}/", $source, $match))
    {
      $ml = str_replace($match[3], "<", $match[1]);
      $mi = str_replace($match[4], "<", $match[2]);
      $no = $match[5];
      $ot = '';
      for ($i = 0; $i < strlen($mi); $i++) 
      {
        $ot .= $ml[ord($mi[$i]) - $no];
      }
      preg_match("/<a[\s]*href\=\'mailto\:(.*)'>(.*)<\/a>/", $ot, $email_array);
      if (isset($email_array[1])) $email = $email_array[1];
      $ver = '7';
    } 
    else 
    {
      preg_match("/<a[\s]*href\=\'mailto\:(.*)'>(.*)<\/a>/", $source, $email_array);
      if (isset($email_array[1])) 
      {
        $email = $email_array[1];
        $ver = '6';
      }
    }
  }    
}

function getuserfromemail($email, &$user_id, &$user_name)
{
  $result = dbquery("SELECT user_id, user_name FROM ".DB_USERS." WHERE user_email = '".$email."' ;");
  if ($data = dbarray($result))
  {
    $user_id = $data['user_id'];
    $user_name = $data['user_name'];
  }
  else
  {
    $user_id = 0;
    $user_name = '';
  }
}

function parseurl($url)
{
  $url_array = parse_url($url);
  if (!isset($url_array['scheme'])) $url_array['scheme'] = '';
  if (!isset($url_array['host'])) $url_array['host'] = '';
  if (!isset($url_array['query'])) $url_array['query'] = '';

  if (isset($url_array['path']))
  {
    $path_array = pathinfo($url_array['path']);
    $url_array['path'] = $path_array['dirname'];
    if ($url_array['path'] == '/') $url_array['path'] = '';
    $url_array['file'] = $path_array['basename'];
  }
  else
  {
    $url_array['path'] = '';
    $url_array['file'] = '';
  }

  return $url_array;
}

function buildurl($url_array, $file)
{
  $url = $url_array['scheme']."://".$url_array['host'].$url_array['path'].'/';
  $url .= isset($file)? $file: $url_array['file'];
  return $url;
}
?>
