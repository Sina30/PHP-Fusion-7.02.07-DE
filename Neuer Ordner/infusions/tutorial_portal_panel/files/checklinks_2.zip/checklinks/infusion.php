<?php
/*-------------------------------------------------------+
| PHP-Fusion Content Management System
| Copyright � 2002 - 2008 Nick Jones
| http://www.php-fusion.co.uk/
+--------------------------------------------------------+
| Filename: infusion.php - Checklinks v1.1
| Author: flj / Flemming Jensen 2008-09-26
+--------------------------------------------------------+
| This program is released as free software under the
| Affero GPL license. You can redistribute it and/or
| modify it under the terms of this license which you
| can read by viewing the included agpl.txt or online
| at www.gnu.org/licenses/agpl.html. Removal of this
| copyright header is strictly prohibited without
| written permission from the original author(s).
+--------------------------------------------------------*/

if (!defined("IN_FUSION")) { die("Access Denied"); }

include INFUSIONS."checklinks/infusion_db.php";

// Check if locale file is available matching the current site locale setting.
if (file_exists(INFUSIONS."checklinks/locale/".$settings['locale'].".php")) {
	// Load the locale file matching the current site locale setting.
	include INFUSIONS."checklinks/locale/".$settings['locale'].".php";
} else {
	// Load the infusion's default locale file.
	include INFUSIONS."checklinks/locale/English.php";
}

// Infusion general information
$inf_title = $locale['CWL_100'];
$inf_description = $locale['CWL_101'];
$inf_version = "1.1";
$inf_developer = "Flemming Jensen (flj)";
$inf_email = "flj@php-fusion.dk";
$inf_weburl = "http://www.php-fusion.dk";

$inf_folder = "checklinks";

$inf_sitelink[1] = array(
	"title" => $locale['CWL_100'],
	"url" => "checklinks.php",
	"visibility" => "102"
);

?>