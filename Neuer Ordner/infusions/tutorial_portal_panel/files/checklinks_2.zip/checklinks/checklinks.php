<?php
/*-------------------------------------------------------+
| PHP-Fusion Content Management System
| Copyright � 2002 - 2008 Nick Jones
| http://www.php-fusion.co.uk/
+--------------------------------------------------------+
| Filename: checklinks.php - Checking weblinks v1.1
| Author: flj / Flemming Jensen 2008-09-26
+--------------------------------------------------------+
| This program is released as free software under the
| Affero GPL license. You can redistribute it and/or
| modify it under the terms of this license which you
| can read by viewing the included agpl.txt or online
| at www.gnu.org/licenses/agpl.html. Removal of this
| copyright header is strictly prohibited without
| written permission from the original author(s).
+--------------------------------------------------------*/

// Settings - change at appropriate
$ext          = FALSE;  // Change to TRUE to use extended checking and get more info
$row_range    = 3;      // For pagenav - can be changed as appropriate
$timeout      = 2;      // A low value to reduce execution time, but not so low that active pages are reported inactive - can be changed as appropriate
$rows_perpage = 10;     // Default rows per page to show
$sort         = 'name'; // Change between 'id', 'cat', 'name' and 'url' as the default sorting

// Includes
require_once "../../maincore.php";
if (!iADMIN || !checkrights("W")) { redirect("../../index.php"); }

if (file_exists(INFUSIONS."checklinks/locale/".$settings['locale'].".php"))
	include INFUSIONS."checklinks/locale/".$settings['locale'].".php";
else
	include INFUSIONS."checklinks/locale/English.php";

if ($ext && file_exists(INFUSIONS."checklinks/checklinks_ext.php"))
{
  include INFUSIONS."checklinks/checklinks_ext.php";
  $ext = checklinks_ext(0, $name_info, $url_info, $status_info)? TRUE: FALSE;
}
else
{
  $ext = FALSE;
}

// Settings - do not change
$sort_strings =  array('id'   => 'wl.weblink_id ',
                       'cat'  => 'wl.weblink_cat, wl.weblink_name ',
                       'name' => 'wl.weblink_name ',
                       'url'  => 'wl.weblink_url');

$msg_strings  =  array(1      => $locale['CWL_901'],
                       2      => $locale['CWL_902']);

$opts         = stream_context_create(array("http" => array("timeout" => $timeout)));

// Get GET and POST settings
$row_start    = (isset($_GET['rowstart'])   && isnum($_GET['rowstart']))                              ? $_GET['rowstart']   : 0;
$rows_perpage = (isset($_GET['rowspp'])     && isnum($_GET['rowspp']) && $_GET['rowspp'] > 0)         ? $_GET['rowspp']     : $rows_perpage;
$sort         = (isset($_GET['sort'])       && isset($sort_strings[$_GET['sort']]))                   ? $_GET['sort']       : $sort;
$action       = (isset($_GET['action'])     && $_GET['action'] == 'd')                                ? $_GET['action']     : '';
$id           = (isset($_GET['id'])         && isnum($_GET['id']))                                    ? $_GET['id']         : -1;
$msg          = (isset($_GET['msg'])        && isnum($_GET['msg']))                                   ? $_GET['msg']        : -1;
$rows_perpage = (isset($_POST['newrowspp']) && isnum($_POST['newrowspp']) && $_POST['newrowspp'] > 0) ? $_POST['newrowspp'] : $rows_perpage;

// Delete
if ($action == 'd' && $id > 0)
{
  // Delete the post
  $result = dbquery("DELETE FROM ".DB_WEBLINKS." WHERE weblink_id='".$id."' LIMIT 1 ;");
  $msg = ($result == 1)? 1: 2;
  
  redirect(makeredirect($row_start, $rows_perpage, $sort, '', -1, $msg));
}

// Header
require_once THEMES."templates/header.php";

// Overview section
$result = dbquery("SELECT wc.weblink_cat_id as cat_id, wc.weblink_cat_name as cat_name, COUNT(*) AS no_cat FROM ".DB_WEBLINKS." wl 
                   LEFT JOIN ".DB_WEBLINK_CATS." wc ON wl.weblink_cat = wc.weblink_cat_id 
                   GROUP BY wl.weblink_cat ;");

opentable($locale['CWL_201']);
echo("<br /><table>");
echo("<tr class='tbl1'>
      <td align='left' width='25'><b>".$locale['CWL_211']."</b></td>
      <td align='left' width='200'><b>".$locale['CWL_212']."</b></td>
      <td align='left' width='50'><b>".$locale['CWL_213']."</b></td>
      </tr>");
$rows_tot = 0;
while($data = dbarray($result))
{

  $cat_id   = $data['cat_id'];
  $cat_name = $data['cat_name'];
  $no_cat   = $data['no_cat'];

  $rows_tot = $rows_tot + $no_cat;
  echo("<tr class='tbl2'>
        <td align='right'>".$cat_id."</td>
        <td align='left'><a href='".BASEDIR."weblinks.php?cat_id=".$cat_id."' target='_blank'>".$cat_name."</a></td>
        <td align='right'>".$no_cat."</td>
        </tr>");
} 
echo("<tr class='tbl1'>
      <td align='right'> </td>
      <td align='left'><b>".$locale['CWL_214']."</b></td>
      <td align='right'><b>".$rows_tot."</b></td>
      </tr>");
echo("</table><br />");
closetable();

// Links section
opentable($locale['CWL_100']);

// Message - if any
if ($msg >= 0) echo("<br /><div style='color:red'><b>".$msg_strings[$msg]."</b></div><br />");

// Form to set $rows_perpage
echo("<br /><form name='checklinksform' method='post' action='".makeredirect(-1, $rows_perpage, $sort, '', -1, -1)."'>\n");
echo("<table>");
echo("<tr>
      <td width='175'>".$locale['CWL_301'].":</td>
      <td width='50' align='center'><input type='text' name='newrowspp' class='textbox' style='width:40px' value='".$rows_perpage."' /></td>
      <td width='50' align='center'><b><input type='submit' name='".$locale['CWL_302']."' value='".$locale['CWL_302']."' class='button' style='width:40px'/></b></td>
      </tr>\n");
echo("</table></form><br />\n");

// Table with the links to show
$query = "SELECT * FROM ".DB_WEBLINKS." wl 
          LEFT JOIN ".DB_WEBLINK_CATS." wc ON wl.weblink_cat = wc.weblink_cat_id  
          ORDER BY ".$sort_strings[$sort]."   
          LIMIT ".$row_start.",".$rows_perpage." ;";
$result = dbquery($query);

echo("<table>");
echo("<tr class='tbl1'>
      <td align='left' valign='top' width='25'><a href='". makeredirect(-1, $rows_perpage, 'id',   '', -1, -1)."' title='".$locale['CWL_406']."'><b>".$locale['CWL_401']."</b></a></td>
      <td align='left' valign='top' width='200'><a href='".makeredirect(-1, $rows_perpage, 'cat',  '', -1, -1)."' title='".$locale['CWL_406']."'><b>".$locale['CWL_402']."</b></a></td>
      <td align='left' valign='top' width='200'><a href='".makeredirect(-1, $rows_perpage, 'name', '', -1, -1)."' title='".$locale['CWL_406']."'><b>".$locale['CWL_403']."</b></a></td>
      <td align='left' valign='top' width='100'><a href='".makeredirect(-1, $rows_perpage, 'url',  '', -1, -1)."' title='".$locale['CWL_406']."'><b>".$locale['CWL_404']."</b></a></td>
      <td align='left' valign='top' width='50'><b>".$locale['CWL_405']."</b></td>
      <td align='left' valign='top' width='60'> </td>
      </tr>");
while($data = dbarray($result)) 
{
  $id          = $data['weblink_id'];
  $name        = $data['weblink_name'];
  $url         = $data['weblink_url'];
  $description = $data['weblink_description'];
  $cat_id      = $data['weblink_cat'];
  $cat_name    = $data['weblink_cat_name'];
  $ext_rtn     = FALSE;
  
  if (checkurl($url))
  {  
    if (checklink($url, $opts))
    {
      $status = $locale['CWL_411'];
      $color = 'green';
      
      if ($ext) { $ext_rtn = checklinks_ext($url, $name_info, $url_info, $status_info); }
    }
    else
    {
      $status = $locale['CWL_412'];
      $color = 'red';
    }
  }
  else
  {
    $status = $locale['CWL_413'];
      $color = 'red';
  }
  $page_link   = "<a href='".$url."' target='_blank' title='".$description."'>".trimlink($url, 30)."</a>";
  $edit_link   = "<a href='".ADMIN."weblinks.php".$aidlink."&action=edit&weblink_cat_id=".$cat_id."&weblink_id=".$id."' target='_blank'>".$locale['CWL_421']."</a>";
  $delete_link = "<a href='".makeredirect($row_start, $rows_perpage, $sort, 'd', $id, -1)."' onclick=\"return confirm('".$locale['CWL_423']."');\" target='_self'>".$locale['CWL_422']."</a>";
  $status      = "<div style='color:".$color."'>".$status."</div>";
  
  if ($ext_rtn)
  {
    $name      .= "<br />".$name_info;
    $page_link .= "<br />".$url_info;
    $status    .= $status_info;
  }

  echo("<tr class='tbl1'>
        <td align='right' valign='top'>".$id."</td>
        <td align='left' valign='top'>".$cat_name."</td>
        <td align='left' valign='top'>".$name."</td>
        <td align='left' valign='top'>".$page_link."</td>
        <td align='left' valign='top'>".$status."</td>
        <td align='left' valign='top'>".$edit_link." ".$delete_link."</td>
        </tr>");
}

echo("</table><br />");

// Page navigation
echo("<div align='center'>".makepagenav($row_start, $rows_perpage, $rows_tot, $row_range, makeredirect(-1, $rows_perpage, $sort, '', -1, -1))."</div>\n");
closetable();

// Footer
require_once THEMES."templates/footer.php";

// Check url syntax and return TRUE if ok, FALSE otherwise
function checkurl($url)
{
  $status = preg_match('|^http(s)?://[a-z0-9-]+(.[a-z0-9-]+)*(:[0-9]+)?(/.*)?$|i', $url)? TRUE: FALSE;
  return $status; 
}  

// Check that url is active and return TRUE if ok, FALSE otherwise
function checklink($url, $opts)
{
  if ($fp = @fopen($url, "r", FALSE, $opts))
  {
    fclose($fp);
    $status = TRUE;
  }
  else
  {
    $status = FALSE;
  }

  return $status;
}

// Prepares a url for redirect with the arguments used by checklinks
// Blank/negative arguments will omit that argument in the url
function makeredirect($row_start, $rows_perpage, $sort, $action, $id, $msg)
{
  $url = FUSION_SELF."?";
  if ($rows_perpage > 0)        $url .= "rowspp=".  $rows_perpage."&";
  if ($sort != '')              $url .= "sort=".    $sort."&";
  if ($action != '' && $id > 0) $url .= "action=".  $action."&id=".$id."&";
  if ($msg > 0)                 $url .= "msg=".     $msg."&";
  if ($row_start > 0)           $url .= "rowstart=".$row_start."&";
  
  return $url;
}
?>