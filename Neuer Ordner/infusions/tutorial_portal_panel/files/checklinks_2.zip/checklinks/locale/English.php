<?php
// English locale file for Member Page Statistics infusion

// General data
$locale['CWL_100'] = "Check web-links";
$locale['CWL_101'] = "Admin tool for maintaining weblinks, including checking whether they are active";

// Overview section
$locale['CWL_201'] = "Overview of web-links";
$locale['CWL_211'] = "Id";
$locale['CWL_212'] = "Category";
$locale['CWL_213'] = "Count";
$locale['CWL_214'] = "TOTAL";

// Form
$locale['CWL_301'] = "Links per page";
$locale['CWL_302'] = "Set";

// Links
$locale['CWL_401'] = "Id";
$locale['CWL_402'] = "Category";
$locale['CWL_403'] = "Name";
$locale['CWL_404'] = "Url";
$locale['CWL_405'] = "Status";
$locale['CWL_406'] = "Click to sort";

$locale['CWL_411'] = "ok";
$locale['CWL_412'] = "not active";
$locale['CWL_413'] = "illegal url";

$locale['CWL_421'] = "edit";
$locale['CWL_422'] = "delete";
$locale['CWL_423'] = "Delete this web-link?";

// Messages
$locale['CWL_901'] = "Link deleted";
$locale['CWL_902'] = "ERROR: Could not delete link";
?>